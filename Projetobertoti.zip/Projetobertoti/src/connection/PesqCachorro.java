/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connection;

import static connection.ConnectionFactory.getConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

/**
 *
 * @author Diane Alves
 */
public class PesqCachorro {
    
    public PesqCachorro() throws Exception {
        
    }
    
    public Vector Pesquisar (String pesq) throws Exception {
      Vector tb = new Vector ();
      String url = "select * from cachorro where nome like '" + pesq + "%'";
      PreparedStatement stmt = getConnection().prepareStatement(url);
      ResultSet rs = stmt.executeQuery();
      while(rs.next()) {
          Vector nl = new Vector();
          nl.add(rs.getInt("Id"));
          nl.add(rs.getString("raca"));
          nl.add(rs.getString("nome"));
          nl.add(rs.getString("peso"));
          tb.add(nl);
      }
      return tb;
    }
}
