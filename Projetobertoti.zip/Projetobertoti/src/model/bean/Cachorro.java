/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.bean;

/**
 *
 * @author Diane Alves
 */
public class Cachorro {
    private String raca;
    private String nome;
    private String peso;

    public String getRaca() {
        return raca;
    }

    public String getNome() {
        return nome;
    }

    public String getPeso() {
        return peso;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }
    
    
}
